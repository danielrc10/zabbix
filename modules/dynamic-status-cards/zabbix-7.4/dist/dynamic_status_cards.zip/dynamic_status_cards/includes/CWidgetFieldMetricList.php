<?php declare(strict_types = 0);

/**
 * PT-BR: Campo composto que armazena as métricas configuradas no widget.
 * EN: Composite field that stores the metrics configured in the widget.
 *
 * Autor / Author: Daniel Carvalho <danielrc10@gmail.com>
 * LinkedIn: https://www.linkedin.com/in/daniel-ti/
 * Licença / License: PolyForm Noncommercial 1.0.0
 * Uso comercial / Commercial use: contato / contact danielrc10@gmail.com
 */

namespace Modules\DynamicStatusCards\Includes;

use DB;
use Zabbix\Widgets\CWidgetField;

class CWidgetFieldMetricList extends CWidgetField {

	public const DEFAULT_VIEW = CWidgetFieldMetricListView::class;
	public const DEFAULT_VALUE = [];

	public const FORMATO_AUTOMATICO = 'automatico';
	public const FORMATO_MAPA = 'mapa';
	public const FORMATO_NUMERO = 'numero';
	public const FORMATO_DATA = 'data';
	public const FORMATO_TEXTO = 'texto';

	public const ESTADO_NENHUM = 'nenhum';
	public const ESTADO_LIMITES = 'limiares';
	public const ESTADO_VALORES = 'valores';

	public const DIRECAO_MAIOR_PIOR = 'maior_pior';
	public const DIRECAO_MENOR_PIOR = 'menor_pior';

	public const ESTADOS = ['neutro', 'ok', 'aviso', 'critico'];

	public function __construct(string $name, ?string $label = null) {
		parent::__construct($name, $label);
		$this->setDefault(self::DEFAULT_VALUE);
	}

	public static function getMetricDefaults(): array {
		return [
			'rotulo' => '',
			'padroes' => [],
			'formato' => self::FORMATO_AUTOMATICO,
			'mapa' => '',
			'decimais' => 0,
			'sufixo' => '',
			'formato_data' => 'd/m/Y',
			'padroes_estado' => [],
			'estado_modo' => self::ESTADO_NENHUM,
			'direcao' => self::DIRECAO_MAIOR_PIOR,
			'limite_aviso' => '',
			'limite_critico' => '',
			'valores_ok' => '',
			'valores_aviso' => '',
			'valores_critico' => '',
			'estado_padrao' => 'neutro',
			'obrigatorio' => 1
		];
	}

	/**
	 * PT-BR: Aceita o JSON da versão 1.0 e o converte uma única vez ao salvar.
	 * EN: Accepts the 1.0 JSON payload and converts it once the widget is saved.
	 */
	public function setValue($value): self {
		if (is_string($value)) {
			$legacy = json_decode($value, true);
			$value = is_array($legacy) ? $legacy : [];
		}

		if (!is_array($value)) {
			return parent::setValue([]);
		}

		$metricas = [];
		foreach (array_values($value) as $metrica) {
			if (is_array($metrica)) {
				$metricas[] = $this->normalizarMetrica($metrica);
			}
		}

		return parent::setValue($metricas);
	}

	public function validate(bool $strict = false): array {
		$erros = parent::validate($strict);
		if ($erros) {
			return $erros;
		}

		foreach ($this->getValue() as $indice => $metrica) {
			$numero = $indice + 1;

			if ($metrica['estado_modo'] === self::ESTADO_LIMITES) {
				if (!is_numeric($metrica['limite_aviso']) || !is_numeric($metrica['limite_critico'])) {
					$erros[] = "Métrica {$numero}: os limites de aviso e crítico precisam ser numéricos.";
					continue;
				}

				$aviso = (float) $metrica['limite_aviso'];
				$critico = (float) $metrica['limite_critico'];
				if ($metrica['direcao'] === self::DIRECAO_MAIOR_PIOR && $aviso >= $critico) {
					$erros[] = "Métrica {$numero}: quando valores maiores são piores, o limite de aviso deve ser menor que o crítico.";
				}
				if ($metrica['direcao'] === self::DIRECAO_MENOR_PIOR && $critico >= $aviso) {
					$erros[] = "Métrica {$numero}: quando valores menores são piores, o limite crítico deve ser menor que o de aviso.";
				}
			}
			elseif ($metrica['estado_modo'] === self::ESTADO_VALORES
					&& trim($metrica['valores_ok']) === ''
					&& trim($metrica['valores_aviso']) === ''
					&& trim($metrica['valores_critico']) === ''
					&& $metrica['estado_padrao'] === 'neutro') {
				$erros[] = "Métrica {$numero}: informe pelo menos um valor ou um estado padrão.";
			}
		}

		return $erros;
	}

	public function toApi(array &$widget_fields = []): void {
		$tipos = [
			'rotulo' => ZBX_WIDGET_FIELD_TYPE_STR,
			'formato' => ZBX_WIDGET_FIELD_TYPE_STR,
			'mapa' => ZBX_WIDGET_FIELD_TYPE_STR,
			'decimais' => ZBX_WIDGET_FIELD_TYPE_INT32,
			'sufixo' => ZBX_WIDGET_FIELD_TYPE_STR,
			'formato_data' => ZBX_WIDGET_FIELD_TYPE_STR,
			'estado_modo' => ZBX_WIDGET_FIELD_TYPE_STR,
			'direcao' => ZBX_WIDGET_FIELD_TYPE_STR,
			'limite_aviso' => ZBX_WIDGET_FIELD_TYPE_STR,
			'limite_critico' => ZBX_WIDGET_FIELD_TYPE_STR,
			'valores_ok' => ZBX_WIDGET_FIELD_TYPE_STR,
			'valores_aviso' => ZBX_WIDGET_FIELD_TYPE_STR,
			'valores_critico' => ZBX_WIDGET_FIELD_TYPE_STR,
			'estado_padrao' => ZBX_WIDGET_FIELD_TYPE_STR,
			'obrigatorio' => ZBX_WIDGET_FIELD_TYPE_INT32
		];

		foreach ($this->getValue() as $indice => $metrica) {
			foreach ($tipos as $campo => $tipo) {
				$widget_fields[] = [
					'type' => $tipo,
					'name' => $this->name.'.'.$indice.'.'.$campo,
					'value' => $metrica[$campo]
				];
			}

			foreach ($metrica['padroes'] as $padrao_indice => $padrao) {
				$widget_fields[] = [
					'type' => ZBX_WIDGET_FIELD_TYPE_STR,
					'name' => $this->name.'.'.$indice.'.padroes.'.$padrao_indice,
					'value' => $padrao
				];
			}

			foreach ($metrica['padroes_estado'] as $padrao_indice => $padrao) {
				$widget_fields[] = [
					'type' => ZBX_WIDGET_FIELD_TYPE_STR,
					'name' => $this->name.'.'.$indice.'.padroes_estado.'.$padrao_indice,
					'value' => $padrao
				];
			}
		}
	}

	protected function getValidationRules(bool $strict = false): array {
		$maximo = DB::getFieldLength('widget_field', 'value_str');
		$regras = ['type' => API_OBJECTS, 'fields' => [
			'rotulo' => ['type' => API_STRING_UTF8, 'flags' => API_REQUIRED | API_NOT_EMPTY, 'length' => 255],
			'padroes' => ['type' => API_STRINGS_UTF8, 'flags' => API_REQUIRED | API_NOT_EMPTY],
			'formato' => ['type' => API_STRING_UTF8, 'in' => implode(',', [
				self::FORMATO_AUTOMATICO,
				self::FORMATO_MAPA,
				self::FORMATO_NUMERO,
				self::FORMATO_DATA,
				self::FORMATO_TEXTO
			]), 'default' => self::FORMATO_AUTOMATICO],
			'mapa' => ['type' => API_STRING_UTF8, 'length' => $maximo, 'default' => ''],
			'decimais' => ['type' => API_INT32, 'in' => '0:6', 'default' => 0],
			'sufixo' => ['type' => API_STRING_UTF8, 'length' => 64, 'default' => ''],
			'formato_data' => ['type' => API_STRING_UTF8, 'length' => 64, 'default' => 'd/m/Y'],
			'padroes_estado' => ['type' => API_STRINGS_UTF8, 'default' => []],
			'estado_modo' => ['type' => API_STRING_UTF8, 'in' => implode(',', [
				self::ESTADO_NENHUM,
				self::ESTADO_LIMITES,
				self::ESTADO_VALORES
			]), 'default' => self::ESTADO_NENHUM],
			'direcao' => ['type' => API_STRING_UTF8, 'in' => implode(',', [
				self::DIRECAO_MAIOR_PIOR,
				self::DIRECAO_MENOR_PIOR
			]), 'default' => self::DIRECAO_MAIOR_PIOR],
			'limite_aviso' => ['type' => API_STRING_UTF8, 'length' => 64, 'default' => ''],
			'limite_critico' => ['type' => API_STRING_UTF8, 'length' => 64, 'default' => ''],
			'valores_ok' => ['type' => API_STRING_UTF8, 'length' => $maximo, 'default' => ''],
			'valores_aviso' => ['type' => API_STRING_UTF8, 'length' => $maximo, 'default' => ''],
			'valores_critico' => ['type' => API_STRING_UTF8, 'length' => $maximo, 'default' => ''],
			'estado_padrao' => ['type' => API_STRING_UTF8, 'in' => implode(',', self::ESTADOS), 'default' => 'neutro'],
			'obrigatorio' => ['type' => API_INT32, 'in' => '0,1', 'default' => 1]
		]];

		if (($this->getFlags() & self::FLAG_NOT_EMPTY) !== 0) {
			self::setValidationRuleFlag($regras, API_NOT_EMPTY);
		}

		return $regras;
	}

	private function normalizarMetrica(array $metrica): array {
		if (!array_key_exists('padroes', $metrica)) {
			$metrica['padroes'] = isset($metrica['padrao']) ? [(string) $metrica['padrao']] : [];
		}
		if (!array_key_exists('padroes_estado', $metrica)) {
			$metrica['padroes_estado'] = isset($metrica['padrao_estado'])
				? [(string) $metrica['padrao_estado']]
				: [];
		}

		if (is_array($metrica['mapa'] ?? null)) {
			$linhas = [];
			foreach ($metrica['mapa'] as $valor => $texto) {
				$linhas[] = $valor.'='.$texto;
			}
			$metrica['mapa'] = implode("\n", $linhas);
		}

		if (!array_key_exists('estado_modo', $metrica)) {
			if (is_array($metrica['estados'] ?? null)) {
				$metrica['estado_modo'] = self::ESTADO_VALORES;
				$listas = ['ok' => [], 'aviso' => [], 'critico' => []];
				foreach ($metrica['estados'] as $valor => $estado) {
					if ((string) $valor === '*') {
						$metrica['estado_padrao'] = in_array($estado, self::ESTADOS, true) ? $estado : 'neutro';
					}
					elseif (array_key_exists($estado, $listas)) {
						$listas[$estado][] = (string) $valor;
					}
				}
				$metrica['valores_ok'] = implode(', ', $listas['ok']);
				$metrica['valores_aviso'] = implode(', ', $listas['aviso']);
				$metrica['valores_critico'] = implode(', ', $listas['critico']);
			}
			elseif (is_array($metrica['limites'] ?? null)) {
				$metrica['estado_modo'] = self::ESTADO_LIMITES;
				$this->converterLimitesLegados($metrica);
			}
			else {
				$metrica['estado_modo'] = self::ESTADO_NENHUM;
			}
		}

		$metrica['padroes'] = array_values(array_filter(array_map('strval', (array) $metrica['padroes']), 'strlen'));
		$metrica['padroes_estado'] = array_values(array_filter(
			array_map('strval', (array) $metrica['padroes_estado']),
			'strlen'
		));
		$metrica['obrigatorio'] = (int) ($metrica['obrigatorio'] ?? 1);
		unset(
			$metrica['padrao'],
			$metrica['padrao_estado'],
			$metrica['estados'],
			$metrica['limites']
		);

		return array_replace(self::getMetricDefaults(), $metrica);
	}

	private function converterLimitesLegados(array &$metrica): void {
		$metrica['direcao'] = self::DIRECAO_MAIOR_PIOR;
		foreach ($metrica['limites'] as $limite) {
			if (!is_array($limite)) {
				continue;
			}
			$estado = $limite['estado'] ?? '';
			$operador = $limite['operador'] ?? '';
			if ($estado === 'aviso') {
				$metrica['limite_aviso'] = (string) ($limite['valor'] ?? '');
			}
			if ($estado === 'critico') {
				$metrica['limite_critico'] = (string) ($limite['valor'] ?? '');
				if (in_array($operador, ['<', '<='], true)) {
					$metrica['direcao'] = self::DIRECAO_MENOR_PIOR;
				}
			}
		}
	}
}
